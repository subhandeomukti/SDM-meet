/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface MeetLogoProps {
  className?: string;
  showText?: boolean;
  textSize?: string;
  onClick?: () => void;
}

export const MeetLogo: React.FC<MeetLogoProps> = ({
  className = '',
  showText = true,
  textSize = 'text-[22px]',
  onClick,
}) => {
  return (
    <div 
      className={`flex items-center gap-2.5 cursor-pointer select-none ${className}`}
      onClick={onClick}
    >
      {/* Google Meet 4-color Camera SVG */}
      <svg 
        className="w-10 h-10 shrink-0" 
        viewBox="0 0 48 48" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Right arrow/lens polygon (green) */}
        <path d="M37 24L46 17V31L37 24Z" fill="#00832D" />
        {/* Main camera body (blue) */}
        <rect x="2" y="11" width="35" height="26" rx="4" fill="#0066DA" />
        {/* Top-right corner cut / red badge */}
        <path d="M37 15V11C37 8.79086 35.2091 7 33 7H24L37 17.5V15Z" fill="#EA4335" />
        {/* Bottom-right corner cut / yellow */}
        <path d="M37 33V37C37 39.2091 35.2091 41 33 41H24L37 30.5V33Z" fill="#FBBC04" />
        {/* Bottom green accent */}
        <path d="M2 33V33C2 35.2091 3.79086 37 6 37H33C35.2091 37 37 35.2091 37 33V30.5L25 41H6C3.79086 41 2 39.2091 2 37V33Z" fill="#00AC47" />
        {/* Smooth lens highlight */}
        <circle cx="19.5" cy="24" r="6" fill="#0051B3" />
        <circle cx="19.5" cy="24" r="3.5" fill="#FFFFFF" fillOpacity="0.85" />
      </svg>

      {showText && (
        <div className="flex items-center tracking-tight">
          <span className={`font-medium text-[#5f6368] ${textSize} hover:text-[#202124] transition-colors`}>
            <span className="font-semibold text-[#1a73e8]">SDM</span>
            <span className="ml-1 text-[#3c4043] font-normal">Meet</span>
          </span>
        </div>
      )}
    </div>
  );
};
