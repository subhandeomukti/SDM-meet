/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Video as VideoIcon, 
  VideoOff, 
  Sparkles, 
  Tv, 
  ArrowLeft,
  Settings,
  Shield,
  Volume2,
  Crown
} from 'lucide-react';
import { User } from 'firebase/auth';
import { sounds } from '../services/soundEffects';
import { isDeveloperAccount, DEVELOPER_EMAIL, DEVELOPER_NAME, DeveloperCrownBadge } from '../services/developer';

interface LobbyScreenProps {
  meetingCode: string;
  user: User | null;
  onJoinMeeting: (options: { isMicMuted: boolean; isVideoOff: boolean; isPresenting: boolean }) => void;
  onBackToHome: () => void;
  onOpenSettings: () => void;
}

export const LobbyScreen: React.FC<LobbyScreenProps> = ({
  meetingCode,
  user,
  onJoinMeeting,
  onBackToHome,
  onOpenSettings,
}) => {
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isBlurActive, setIsBlurActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [audioLevel, setAudioLevel] = useState(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Initialize camera & mic preview
  useEffect(() => {
    let localStream: MediaStream | null = null;

    const startMedia = async () => {
      try {
        localStream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });

        setStream(localStream);
        if (videoRef.current) {
          videoRef.current.srcObject = localStream;
        }

        // Setup audio visualizer
        try {
          const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            audioContextRef.current = ctx;
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 64;
            analyserRef.current = analyser;

            const source = ctx.createMediaStreamSource(localStream);
            source.connect(analyser);

            const buffer = new Uint8Array(analyser.frequencyBinCount);
            const checkVolume = () => {
              if (analyserRef.current) {
                analyserRef.current.getByteFrequencyData(buffer);
                let sum = 0;
                for (let i = 0; i < buffer.length; i++) {
                  sum += buffer[i];
                }
                const avg = sum / buffer.length;
                setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
              }
              animFrameRef.current = requestAnimationFrame(checkVolume);
            };
            checkVolume();
          }
        } catch (e) {
          console.warn('Audio visualization not enabled:', e);
        }
      } catch (err) {
        console.warn('Could not access media devices in lobby:', err);
      }
    };

    startMedia();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      if (audioContextRef.current) audioContextRef.current.close().catch(() => {});
      if (localStream) {
        localStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Update track states when toggled
  const toggleMic = () => {
    const nextState = !isMicMuted;
    setIsMicMuted(nextState);
    if (stream) {
      stream.getAudioTracks().forEach((track) => {
        track.enabled = !nextState;
      });
    }
  };

  const toggleVideo = () => {
    const nextState = !isVideoOff;
    setIsVideoOff(nextState);
    if (stream) {
      stream.getVideoTracks().forEach((track) => {
        track.enabled = !nextState;
      });
    }
  };

  const handleJoin = (isPresenting = false) => {
    sounds.playJoinSound();
    onJoinMeeting({
      isMicMuted,
      isVideoOff,
      isPresenting,
    });
  };

  const displayName = user?.displayName || DEVELOPER_NAME;
  const email = user?.email || DEVELOPER_EMAIL;
  const isDev = isDeveloperAccount(email, displayName);

  return (
    <div className="flex-1 flex flex-col justify-center items-center px-4 py-8 max-w-6xl mx-auto w-full min-h-[calc(100vh-64px)]">
      {/* Back button */}
      <div className="w-full flex items-center mb-6">
        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 text-sm font-medium text-[#5f6368] hover:text-[#202124] px-3 py-1.5 rounded-full hover:bg-black/5 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to SDM Meet</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center w-full">
        {/* Left Side: Video Preview Box */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="w-full max-w-xl aspect-video bg-[#202124] rounded-2xl overflow-hidden relative shadow-2xl flex items-center justify-center border border-gray-800">
            {isVideoOff ? (
              <div className="flex flex-col items-center">
                <div className={`w-24 h-24 rounded-full bg-[#1a73e8] text-white text-3xl font-medium flex items-center justify-center shadow-lg uppercase relative ${
                  isDev ? 'ring-4 ring-amber-400' : ''
                }`}>
                  {displayName[0] || 'U'}
                  {isDev && (
                    <div className="absolute -top-2 -right-1 bg-amber-400 text-amber-950 p-1.5 rounded-full shadow">
                      <Crown className="w-5 h-5 fill-amber-950" />
                    </div>
                  )}
                </div>
                <span className="text-white/80 text-sm mt-3 font-medium">Camera is off</span>
              </div>
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover scale-x-[-1] transition-all duration-300 ${
                  isBlurActive ? 'backdrop-blur-md filter blur-[6px]' : ''
                }`}
              />
            )}

            {/* Audio Waveform Meter indicator (Bottom Right of Tile) */}
            <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-md px-2.5 py-1.5 rounded-full flex items-center gap-1.5 text-white text-xs">
              <Volume2 className="w-3.5 h-3.5 text-white/80" />
              <div className="flex items-end gap-0.5 h-3 w-6">
                <span 
                  className={`w-1 bg-[#34a853] rounded-full transition-all ${isMicMuted ? 'h-0.5 opacity-30' : ''}`}
                  style={{ height: isMicMuted ? '2px' : `${Math.max(2, Math.min(12, (audioLevel / 100) * 12))}px` }}
                />
                <span 
                  className={`w-1 bg-[#34a853] rounded-full transition-all ${isMicMuted ? 'h-0.5 opacity-30' : ''}`}
                  style={{ height: isMicMuted ? '2px' : `${Math.max(2, Math.min(12, (audioLevel / 80) * 12))}px` }}
                />
                <span 
                  className={`w-1 bg-[#34a853] rounded-full transition-all ${isMicMuted ? 'h-0.5 opacity-30' : ''}`}
                  style={{ height: isMicMuted ? '2px' : `${Math.max(2, Math.min(12, (audioLevel / 60) * 12))}px` }}
                />
              </div>
            </div>

            {/* Controls Bar over Video */}
            <div className="absolute bottom-5 inset-x-0 flex items-center justify-center gap-4 z-10">
              {/* Mic toggle */}
              <button
                onClick={toggleMic}
                className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
                  isMicMuted
                    ? 'bg-[#ea4335] text-white hover:bg-[#d93025]'
                    : 'bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/20'
                }`}
                title={isMicMuted ? 'Turn on microphone (Ctrl + d)' : 'Turn off microphone (Ctrl + d)'}
              >
                {isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              {/* Video toggle */}
              <button
                onClick={toggleVideo}
                className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
                  isVideoOff
                    ? 'bg-[#ea4335] text-white hover:bg-[#d93025]'
                    : 'bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/20'
                }`}
                title={isVideoOff ? 'Turn on camera (Ctrl + e)' : 'Turn off camera (Ctrl + e)'}
              >
                {isVideoOff ? <VideoOff className="w-5 h-5" /> : <VideoIcon className="w-5 h-5" />}
              </button>

              {/* Visual effects / blur */}
              <button
                onClick={() => setIsBlurActive(!isBlurActive)}
                className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${
                  isBlurActive
                    ? 'bg-[#1a73e8] text-white'
                    : 'bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/20'
                }`}
                title="Apply visual effects & background blur"
              >
                <Sparkles className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-4 text-xs text-[#5f6368]">
            <button 
              onClick={onOpenSettings}
              className="flex items-center gap-1.5 hover:text-[#1a73e8] transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Check your audio and video</span>
            </button>
          </div>
        </div>

        {/* Right Side: Join Actions & Info */}
        <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left">
          <h2 className="text-3xl font-normal text-[#202124]">
            Ready to join?
          </h2>
          
          <div className="mt-2 flex items-center gap-2">
            <span className="text-sm font-mono text-[#5f6368] bg-[#f1f3f4] px-2.5 py-1 rounded-md">
              {meetingCode}
            </span>
            <div className="flex items-center gap-1 text-xs text-[#137333] font-medium bg-[#e6f4ea] px-2 py-0.5 rounded-full">
              <Shield className="w-3 h-3" />
              <span>Encrypted</span>
            </div>
          </div>

          <p className="mt-4 text-sm text-[#5f6368]">
            No one else is here yet. Be the first to start the call!
          </p>

          {/* Action Buttons */}
          <div className="mt-8 flex items-center gap-3">
            <button
              onClick={() => handleJoin(false)}
              className="px-8 py-3 bg-[#1a73e8] hover:bg-[#1557b0] text-white font-medium text-sm rounded-full shadow-md hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer"
            >
              Join now
            </button>

            <button
              onClick={() => handleJoin(true)}
              className="px-6 py-3 border border-[#dadce0] hover:bg-[#f8f9fa] text-[#1a73e8] font-medium text-sm rounded-full transition-all flex items-center gap-2 cursor-pointer"
            >
              <Tv className="w-4 h-4" />
              <span>Present</span>
            </button>
          </div>

          {/* Joining as user identity */}
          <div className="mt-10 pt-6 border-t border-[#dadce0] w-full max-w-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#5f6368] block">Joining as</span>
              {isDev && <DeveloperCrownBadge size="sm" />}
            </div>
            
            <div className="flex items-center gap-3 mt-1.5">
              <div className={`w-9 h-9 rounded-full bg-[#1a73e8] text-white text-xs font-semibold flex items-center justify-center uppercase relative ${
                isDev ? 'ring-2 ring-amber-400' : ''
              }`}>
                {displayName[0] || 'U'}
                {isDev && (
                  <div className="absolute -top-1.5 -right-1 bg-amber-400 rounded-full p-0.5 shadow">
                    <Crown className="w-2.5 h-2.5 fill-amber-950 text-amber-950" />
                  </div>
                )}
              </div>
              <div className="text-left overflow-hidden">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-semibold text-[#202124] block truncate">
                    {displayName}
                  </span>
                  {isDev && (
                    <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-400 shrink-0" />
                  )}
                </div>
                <span className="text-xs text-[#5f6368] block truncate font-mono">
                  {email}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
