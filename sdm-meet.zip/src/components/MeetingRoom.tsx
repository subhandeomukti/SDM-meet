/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Video as VideoIcon, 
  VideoOff, 
  PhoneOff, 
  Hand, 
  Tv, 
  MoreVertical, 
  Smile, 
  Subtitles, 
  Info, 
  Users, 
  MessageSquare, 
  Shapes, 
  Copy, 
  Check, 
  Send, 
  X, 
  Maximize, 
  Minimize, 
  Sparkles, 
  Settings, 
  PenTool, 
  UserPlus, 
  ShieldCheck,
  Volume2,
  Crown
} from 'lucide-react';
import { User } from 'firebase/auth';
import { sounds } from '../services/soundEffects';
import { isDeveloperAccount, DEVELOPER_EMAIL, DEVELOPER_NAME, DeveloperCrownBadge } from '../services/developer';

interface Participant {
  id: string;
  name: string;
  isHost?: boolean;
  isMuted: boolean;
  isVideoOff: boolean;
  isSpeaking: boolean;
  hasHandRaised: boolean;
  avatarColor: string;
  avatarUrl?: string;
}

interface ChatMessage {
  id: string;
  sender: string;
  time: string;
  text: string;
  isSelf?: boolean;
}

interface FloatingReaction {
  id: string;
  emoji: string;
  xOffset: number;
}

interface MeetingRoomProps {
  meetingCode: string;
  user: User | null;
  initialMicMuted?: boolean;
  initialVideoOff?: boolean;
  initialPresenting?: boolean;
  onLeaveMeeting: () => void;
  onOpenSettings: () => void;
  onOpenWhiteboard: () => void;
}

export const MeetingRoom: React.FC<MeetingRoomProps> = ({
  meetingCode,
  user,
  initialMicMuted = false,
  initialVideoOff = false,
  initialPresenting = false,
  onLeaveMeeting,
  onOpenSettings,
  onOpenWhiteboard,
}) => {
  // Local Media State
  const [isMicMuted, setIsMicMuted] = useState(initialMicMuted);
  const [isVideoOff, setIsVideoOff] = useState(initialVideoOff);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [isCaptionsOn, setIsCaptionsOn] = useState(false);
  const [captionText, setCaptionText] = useState('Welcome to SDM Meet. Real-time captions are active.');
  const [isBackgroundBlur, setIsBackgroundBlur] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  // Active side panel: null | 'info' | 'people' | 'chat' | 'activities' | 'host'
  const [activeSidePanel, setActiveSidePanel] = useState<'info' | 'people' | 'chat' | 'activities' | 'host' | null>(null);

  // Screen Sharing
  const [isScreenSharing, setIsScreenSharing] = useState(initialPresenting);
  const screenShareVideoRef = useRef<HTMLVideoElement | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);

  // Local Media Stream
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const [localAudioLevel, setLocalAudioLevel] = useState(0);

  // Reactions
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);

  // Simulated Participants for realistic team experience
  const [participants, setParticipants] = useState<Participant[]>([
    {
      id: 'peer-1',
      name: 'Sarah Wijaya',
      isHost: false,
      isMuted: false,
      isVideoOff: false,
      isSpeaking: false,
      hasHandRaised: false,
      avatarColor: '#1a73e8',
    },
    {
      id: 'peer-2',
      name: 'Budi Santoso',
      isHost: false,
      isMuted: true,
      isVideoOff: true,
      isSpeaking: false,
      hasHandRaised: false,
      avatarColor: '#ea4335',
    },
  ]);

  // Chat
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'Sarah Wijaya',
      time: '10:31 AM',
      text: 'Halo semuanya! Ready for the SDM Meet session.',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const meetingLink = `https://meet.google.com/${meetingCode}`;
  const userName = user?.displayName || DEVELOPER_NAME;
  const userEmail = user?.email || DEVELOPER_EMAIL;
  const isDev = isDeveloperAccount(userEmail, userName);

  // Request user camera and microphone
  useEffect(() => {
    let stream: MediaStream | null = null;
    let animFrame: number;

    const startLocalMedia = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });

        setLocalStream(stream);

        // Apply initial mute states
        if (initialMicMuted) {
          stream.getAudioTracks().forEach((t) => (t.enabled = false));
        }
        if (initialVideoOff) {
          stream.getVideoTracks().forEach((t) => (t.enabled = false));
        }

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Audio analysis
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const audioCtx = new AudioCtx();
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 64;
          const source = audioCtx.createMediaStreamSource(stream);
          source.connect(analyser);

          const buffer = new Uint8Array(analyser.frequencyBinCount);
          const updateAudio = () => {
            analyser.getByteFrequencyData(buffer);
            let sum = 0;
            for (let i = 0; i < buffer.length; i++) sum += buffer[i];
            const avg = sum / buffer.length;
            setLocalAudioLevel(avg > 15 ? Math.min(100, Math.round((avg / 128) * 100)) : 0);
            animFrame = requestAnimationFrame(updateAudio);
          };
          updateAudio();
        }
      } catch (err) {
        console.warn('Unable to access webcam/mic:', err);
      }
    };

    startLocalMedia();

    return () => {
      cancelAnimationFrame(animFrame);
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Handle Screen Share
  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      if (screenStream) {
        screenStream.getTracks().forEach((t) => t.stop());
      }
      setScreenStream(null);
      setIsScreenSharing(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });
        setScreenStream(stream);
        setIsScreenSharing(true);
        if (screenShareVideoRef.current) {
          screenShareVideoRef.current.srcObject = stream;
        }

        stream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
          setScreenStream(null);
        };
      } catch (e) {
        console.warn('Screen share cancelled or failed:', e);
      }
    }
  };

  // Sync screen video element when active
  useEffect(() => {
    if (isScreenSharing && screenStream && screenShareVideoRef.current) {
      screenShareVideoRef.current.srcObject = screenStream;
    }
  }, [isScreenSharing, screenStream]);

  // Audio mute toggle
  const toggleMic = () => {
    const next = !isMicMuted;
    setIsMicMuted(next);
    if (localStream) {
      localStream.getAudioTracks().forEach((t) => (t.enabled = !next));
    }
  };

  // Video toggle
  const toggleVideo = () => {
    const next = !isVideoOff;
    setIsVideoOff(next);
    if (localStream) {
      localStream.getVideoTracks().forEach((t) => (t.enabled = !next));
    }
  };

  // Hand raise
  const toggleHandRaise = () => {
    const next = !isHandRaised;
    setIsHandRaised(next);
    if (next) {
      sounds.playHandRaiseSound();
    }
  };

  // Send Floating Reaction
  const sendReaction = (emoji: string) => {
    sounds.playReactionSound();
    const id = `${Date.now()}-${Math.random()}`;
    const xOffset = Math.floor(Math.random() * 80) + 10; // 10% to 90% across screen
    setReactions((prev) => [...prev, { id, emoji, xOffset }]);
    setShowReactionPicker(false);

    // Auto cleanup after animation
    setTimeout(() => {
      setReactions((prev) => prev.filter((r) => r.id !== id));
    }, 3000);
  };

  // Send chat message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    sounds.playMessageSound();
    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: userName,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: chatInput.trim(),
      isSelf: true,
    };
    setChatMessages((prev) => [...prev, newMsg]);
    setChatInput('');
  };

  // Add simulated guest / colleague
  const handleAddParticipant = () => {
    const names = ['Ahmad Fauzi', 'Maya Lin', 'Rian Hidayat', 'Dina Kartika'];
    const available = names.filter((n) => !participants.some((p) => p.name === n));
    if (available.length === 0) return;

    sounds.playJoinSound();
    const newParticipant: Participant = {
      id: `peer-${Date.now()}`,
      name: available[0],
      isHost: false,
      isMuted: false,
      isVideoOff: false,
      isSpeaking: false,
      hasHandRaised: false,
      avatarColor: ['#00832d', '#ea4335', '#fbbc04', '#9333ea'][Math.floor(Math.random() * 4)],
    };
    setParticipants((prev) => [...prev, newParticipant]);
  };

  const copyMeetingInfo = () => {
    navigator.clipboard.writeText(meetingLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Live Speech Recognition for Captions
  useEffect(() => {
    if (!isCaptionsOn) return;

    const SpeechRecognition = (window as unknown as { SpeechRecognition: any; webkitSpeechRecognition: any }).SpeechRecognition ||
                              (window as unknown as { webkitSpeechRecognition: any }).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'id-ID'; // Indonesian / Multi-language support

        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const transcript = event.results[current][0].transcript;
          setCaptionText(`${userName}: ${transcript}`);
        };

        recognition.onerror = () => {};
        recognition.start();

        return () => {
          recognition.stop();
        };
      } catch (e) {
        console.warn('Speech recognition not available:', e);
      }
    }
  }, [isCaptionsOn, userName]);

  // Periodic random active speaker simulation for peers
  useEffect(() => {
    const interval = setInterval(() => {
      setParticipants((prev) =>
        prev.map((p, idx) => {
          if (idx === 0 && Math.random() > 0.6) {
            return { ...p, isSpeaking: !p.isSpeaking };
          }
          return { ...p, isSpeaking: false };
        })
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const totalParticipants = participants.length + 1; // +1 for local user

  return (
    <div className="relative w-full h-screen bg-[#202124] text-white flex flex-col overflow-hidden select-none">
      {/* Floating Reaction Emojis Container */}
      <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden">
        {reactions.map((r) => (
          <div
            key={r.id}
            className="absolute bottom-24 text-4xl animate-float-reaction drop-shadow-lg"
            style={{ left: `${r.xOffset}%` }}
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* Main Stage View (Video Tiles + Side Panel) */}
      <div className="flex-1 flex overflow-hidden p-3 gap-3 relative">
        {/* Stage Grid */}
        <div className="flex-1 flex flex-col justify-center items-center overflow-hidden relative">
          {/* Active Screen Share View */}
          {isScreenSharing ? (
            <div className="w-full h-full flex flex-col gap-2">
              <div className="flex-1 bg-black rounded-xl overflow-hidden relative flex items-center justify-center border border-gray-800">
                <video
                  ref={screenShareVideoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain"
                />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-2">
                  <Tv className="w-3.5 h-3.5 text-[#1a73e8]" />
                  <span>You are presenting your screen to everyone</span>
                </div>
              </div>

              {/* Strip of participants below screen share */}
              <div className="h-28 flex items-center gap-3 overflow-x-auto pb-1">
                {/* Local user small tile */}
                <div className="h-full aspect-video bg-[#3c4043] rounded-lg overflow-hidden relative shrink-0 border border-gray-700">
                  {isVideoOff ? (
                    <div className="w-full h-full flex items-center justify-center bg-[#282a2d]">
                      <div className="w-10 h-10 rounded-full bg-[#1a73e8] flex items-center justify-center text-sm font-semibold uppercase">
                        {userName[0] || 'Y'}
                      </div>
                    </div>
                  ) : (
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover scale-x-[-1]"
                    />
                  )}
                  <span className="absolute bottom-1.5 left-2 text-[11px] bg-black/50 px-1.5 py-0.5 rounded text-white/90">
                    You
                  </span>
                </div>

                {/* Remote participants small tiles */}
                {participants.map((p) => (
                  <div
                    key={p.id}
                    className="h-full aspect-video bg-[#3c4043] rounded-lg overflow-hidden relative shrink-0 border border-gray-700 flex items-center justify-center"
                  >
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold text-white uppercase shadow"
                      style={{ backgroundColor: p.avatarColor }}
                    >
                      {p.name[0]}
                    </div>
                    <span className="absolute bottom-1.5 left-2 text-[11px] bg-black/50 px-1.5 py-0.5 rounded text-white/90 truncate max-w-[80px]">
                      {p.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Multi-tile grid layout (1 to 4 tiles) */
            <div
              className={`w-full h-full grid gap-3 items-center justify-center ${
                totalParticipants === 1
                  ? 'grid-cols-1 max-w-4xl max-h-[80vh]'
                  : totalParticipants === 2
                  ? 'grid-cols-1 md:grid-cols-2 max-w-5xl'
                  : 'grid-cols-2 max-w-6xl'
              }`}
            >
              {/* Local User Tile */}
              <div
                className={`w-full h-full bg-[#3c4043] rounded-2xl overflow-hidden relative flex items-center justify-center transition-all border ${
                  localAudioLevel > 10 ? 'ring-4 ring-[#1a73e8] border-transparent' : 'border-gray-800'
                }`}
              >
                {isVideoOff ? (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-[#282a2d]">
                    <div className="w-24 h-24 rounded-full bg-[#1a73e8] flex items-center justify-center text-3xl font-semibold uppercase shadow-xl">
                      {userName[0] || 'Y'}
                    </div>
                  </div>
                ) : (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover scale-x-[-1] ${
                      isBackgroundBlur ? 'backdrop-blur-md filter blur-[6px]' : ''
                    }`}
                  />
                )}

                {/* Tile Name Badge */}
                <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 text-white/90">
                  <div className="flex items-center gap-1">
                    <span>{userName} (You)</span>
                    {isDev && (
                      <span title="Developer">
                        <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      </span>
                    )}
                  </div>
                  {isHandRaised && (
                    <span className="bg-[#1a73e8] text-white p-0.5 rounded" title="Hand raised">
                      <Hand className="w-3 h-3 fill-current" />
                    </span>
                  )}
                </div>

                {/* Mic status on tile */}
                <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md p-1.5 rounded-full">
                  {isMicMuted ? (
                    <MicOff className="w-4 h-4 text-[#ea4335]" />
                  ) : (
                    <div className="flex items-center gap-0.5 h-3 px-0.5">
                      <span className="w-1 bg-[#34a853] rounded-full h-3 animate-pulse" />
                      <span className="w-1 bg-[#34a853] rounded-full h-2 animate-pulse" />
                    </div>
                  )}
                </div>
              </div>

              {/* Remote Participants Tiles */}
              {participants.map((p) => (
                <div
                  key={p.id}
                  className={`w-full h-full bg-[#3c4043] rounded-2xl overflow-hidden relative flex items-center justify-center transition-all border ${
                    p.isSpeaking ? 'ring-4 ring-[#1a73e8] border-transparent' : 'border-gray-800'
                  }`}
                >
                  <div className="w-full h-full flex flex-col items-center justify-center bg-[#282a2d]">
                    <div
                      className="w-24 h-24 rounded-full flex items-center justify-center text-3xl font-semibold text-white uppercase shadow-xl"
                      style={{ backgroundColor: p.avatarColor }}
                    >
                      {p.name[0]}
                    </div>
                  </div>

                  {/* Tile Name Badge */}
                  <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 text-white/90">
                    <span>{p.name}</span>
                    {p.hasHandRaised && (
                      <span className="bg-[#1a73e8] text-white p-0.5 rounded">
                        <Hand className="w-3 h-3 fill-current" />
                      </span>
                    )}
                  </div>

                  {/* Mic status on tile */}
                  <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md p-1.5 rounded-full">
                    {p.isMuted ? (
                      <MicOff className="w-4 h-4 text-[#ea4335]" />
                    ) : (
                      <Mic className="w-4 h-4 text-white/90" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Real-time Closed Captions Overlay (when enabled) */}
          {isCaptionsOn && (
            <div className="absolute bottom-4 bg-black/80 backdrop-blur-md text-white px-5 py-2.5 rounded-lg max-w-xl text-center text-sm shadow-xl border border-white/10 animate-in fade-in">
              <span className="text-[#8ab4f8] font-medium mr-1.5">CC:</span>
              <span>{captionText}</span>
            </div>
          )}
        </div>

        {/* Side Panel (Info, People, Chat, Activities, Host) */}
        {activeSidePanel && (
          <aside className="w-80 sm:w-96 bg-white text-[#202124] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200 shrink-0">
            {/* Panel Header */}
            <div className="px-5 py-4 border-b border-[#dadce0] flex items-center justify-between">
              <h3 className="text-lg font-medium">
                {activeSidePanel === 'info' && 'Meeting details'}
                {activeSidePanel === 'people' && 'People'}
                {activeSidePanel === 'chat' && 'In-call messages'}
                {activeSidePanel === 'activities' && 'Activities'}
                {activeSidePanel === 'host' && 'Host controls'}
              </h3>
              <button
                onClick={() => setActiveSidePanel(null)}
                className="p-1 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Panel Content */}
            <div className="flex-1 overflow-y-auto p-5">
              {/* Info / Meeting details Panel */}
              {activeSidePanel === 'info' && (
                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-[#202124]">Joining info</h4>
                  <p className="text-xs text-[#5f6368] break-all select-all font-mono bg-[#f1f3f4] p-3 rounded-lg">
                    {meetingLink}
                  </p>

                  <button
                    onClick={copyMeetingInfo}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-[#e8f0fe] hover:bg-[#d2e3fc] text-[#1a73e8] rounded-full text-sm font-medium transition-colors"
                  >
                    {copiedLink ? <Check className="w-4 h-4 text-[#137333]" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedLink ? 'Joining info copied' : 'Copy joining info'}</span>
                  </button>

                  <div className="pt-4 border-t border-[#dadce0] text-xs text-[#5f6368] space-y-2">
                    <p className="flex items-center gap-1.5 font-medium text-[#202124]">
                      <ShieldCheck className="w-4 h-4 text-[#137333]" />
                      SDM Meet End-to-End Protection
                    </p>
                    <p>Meeting code: <span className="font-mono">{meetingCode}</span></p>
                    {isDev && (
                      <div className="flex items-center gap-1 text-amber-700 bg-amber-50 p-2 rounded-lg font-medium">
                        <Crown className="w-3.5 h-3.5 fill-amber-400 text-amber-600" />
                        <span>Developer Space: subhandeomukti@gmail.com</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* People Panel */}
              {activeSidePanel === 'people' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold uppercase text-[#5f6368]">
                      In call ({totalParticipants})
                    </span>
                    <button
                      onClick={handleAddParticipant}
                      className="flex items-center gap-1 text-xs font-medium text-[#1a73e8] hover:underline"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Add simulated person</span>
                    </button>
                  </div>

                  {/* Local User Entry */}
                  <div className="flex items-center justify-between py-2 border-b border-[#f1f3f4]">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#1a73e8] text-white text-sm font-semibold flex items-center justify-center uppercase relative">
                        {userName[0] || 'Y'}
                        {isDev && (
                          <div className="absolute -top-1 -right-1 bg-amber-400 rounded-full p-0.5 shadow">
                            <Crown className="w-2.5 h-2.5 fill-amber-950 text-amber-950" />
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-medium text-[#202124] block">
                            {userName} (You)
                          </span>
                          {isDev && <DeveloperCrownBadge size="sm" />}
                        </div>
                        <span className="text-xs text-[#5f6368] block">
                          {isDev ? 'Meeting Host • Developer' : 'Meeting host'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-[#5f6368]">
                      {isMicMuted ? <MicOff className="w-4 h-4 text-[#ea4335]" /> : <Mic className="w-4 h-4 text-[#34a853]" />}
                    </div>
                  </div>

                  {/* Remote Participants */}
                  {participants.map((p) => (
                    <div key={p.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-9 h-9 rounded-full text-white text-sm font-semibold flex items-center justify-center uppercase"
                          style={{ backgroundColor: p.avatarColor }}
                        >
                          {p.name[0]}
                        </div>
                        <div>
                          <span className="text-sm font-medium text-[#202124] block">{p.name}</span>
                          <span className="text-xs text-[#5f6368] block">Participant</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-[#5f6368]">
                        {p.isMuted ? <MicOff className="w-4 h-4 text-[#ea4335]" /> : <Mic className="w-4 h-4" />}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Chat Panel */}
              {activeSidePanel === 'chat' && (
                <div className="flex flex-col h-full">
                  <div className="bg-[#f1f3f4] p-3 rounded-lg text-xs text-[#5f6368] mb-3">
                    Messages can only be seen by people in the call and are deleted when the call ends.
                  </div>

                  <div className="flex-1 space-y-3 overflow-y-auto pr-1">
                    {chatMessages.map((msg) => (
                      <div key={msg.id} className="text-sm">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-xs text-[#202124]">
                            {msg.sender}
                          </span>
                          {(msg.isSelf && isDev) || isDeveloperAccount(undefined, msg.sender) ? (
                            <span title="Developer">
                              <Crown className="w-3 h-3 text-amber-500 fill-amber-400 shrink-0" />
                            </span>
                          ) : null}
                          <span className="text-[10px] text-[#5f6368]">{msg.time}</span>
                        </div>
                        <p className="mt-0.5 text-xs text-[#3c4043] leading-relaxed break-words bg-[#f8f9fa] p-2 rounded-lg">
                          {msg.text}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Message Input Box */}
                  <form onSubmit={handleSendMessage} className="mt-4 pt-2 border-t border-[#dadce0] flex items-center gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Send a message to everyone"
                      className="flex-1 text-xs border border-[#dadce0] rounded-full px-3.5 py-2.5 focus:border-[#1a73e8] focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={!chatInput.trim()}
                      className="p-2 rounded-full bg-[#1a73e8] hover:bg-[#1557b0] text-white disabled:opacity-40 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}

              {/* Activities Panel */}
              {activeSidePanel === 'activities' && (
                <div className="space-y-4">
                  <div
                    onClick={onOpenWhiteboard}
                    className="p-4 border border-[#dadce0] hover:border-[#1a73e8] hover:bg-[#f8f9fa] rounded-xl cursor-pointer transition-all flex items-start gap-4"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#e8f0fe] text-[#1a73e8] flex items-center justify-center shrink-0">
                      <PenTool className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-[#202124]">Whiteboarding</h4>
                      <p className="text-xs text-[#5f6368] mt-1">
                        Collaborate on ideas using SDM Jam whiteboard. Draw, sketch, and export.
                      </p>
                    </div>
                  </div>

                  <div
                    onClick={() => alert('Polls feature: Start an instant poll for participants.')}
                    className="p-4 border border-[#dadce0] hover:border-[#1a73e8] hover:bg-[#f8f9fa] rounded-xl cursor-pointer transition-all flex items-start gap-4"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#fce8e6] text-[#d93025] flex items-center justify-center shrink-0">
                      <Shapes className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-[#202124]">Polls & Q&A</h4>
                      <p className="text-xs text-[#5f6368] mt-1">
                        Ask questions and gather instant feedback from all meeting participants.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Host Controls Panel */}
              {activeSidePanel === 'host' && (
                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-[#202124]">Host management</h4>
                  <p className="text-xs text-[#5f6368]">
                    Control meeting permissions and safeguard who can interact.
                  </p>

                  <div className="space-y-3 pt-2">
                    <label className="flex items-center justify-between text-xs font-medium text-[#202124] cursor-pointer">
                      <span>Share their screen</span>
                      <input type="checkbox" defaultChecked className="rounded text-[#1a73e8]" />
                    </label>
                    <label className="flex items-center justify-between text-xs font-medium text-[#202124] cursor-pointer">
                      <span>Send chat messages</span>
                      <input type="checkbox" defaultChecked className="rounded text-[#1a73e8]" />
                    </label>
                    <label className="flex items-center justify-between text-xs font-medium text-[#202124] cursor-pointer">
                      <span>Turn on their microphone</span>
                      <input type="checkbox" defaultChecked className="rounded text-[#1a73e8]" />
                    </label>
                  </div>
                </div>
              )}
            </div>
          </aside>
        )}
      </div>

      {/* Bottom Google Meet Floating Control Bar */}
      <footer className="h-20 bg-[#202124] px-6 flex items-center justify-between select-none z-40 border-t border-white/5">
        {/* Left: Meeting Info & Code */}
        <div className="hidden md:flex items-center gap-2 text-sm font-medium text-white/90">
          <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <span className="text-white/40">|</span>
          <span className="font-mono text-xs">{meetingCode}</span>
        </div>

        {/* Center: In-Call Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3 mx-auto">
          {/* Microphone toggle */}
          <button
            onClick={toggleMic}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isMicMuted
                ? 'bg-[#ea4335] text-white hover:bg-[#d93025]'
                : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
            }`}
            title={isMicMuted ? 'Turn on microphone (Ctrl + d)' : 'Turn off microphone (Ctrl + d)'}
          >
            {isMicMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Camera toggle */}
          <button
            onClick={toggleVideo}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isVideoOff
                ? 'bg-[#ea4335] text-white hover:bg-[#d93025]'
                : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
            }`}
            title={isVideoOff ? 'Turn on camera (Ctrl + e)' : 'Turn off camera (Ctrl + e)'}
          >
            {isVideoOff ? <VideoOff className="w-5 h-5" /> : <VideoIcon className="w-5 h-5" />}
          </button>

          {/* Captions toggle */}
          <button
            onClick={() => setIsCaptionsOn(!isCaptionsOn)}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isCaptionsOn
                ? 'bg-[#8ab4f8] text-[#202124]'
                : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
            }`}
            title="Turn on/off captions"
          >
            <Subtitles className="w-5 h-5" />
          </button>

          {/* Send Reaction button */}
          <div className="relative">
            <button
              onClick={() => setShowReactionPicker(!showReactionPicker)}
              className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
                showReactionPicker
                  ? 'bg-[#8ab4f8] text-[#202124]'
                  : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
              }`}
              title="Send a reaction"
            >
              <Smile className="w-5 h-5" />
            </button>

            {/* Emoji palette popup */}
            {showReactionPicker && (
              <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-[#3c4043] rounded-full px-3 py-2 flex items-center gap-2 shadow-2xl z-50 animate-in fade-in">
                {['❤️', '👍', '🎉', '👏', '😂', '😮', '😢', '🤔', '👎'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => sendReaction(emoji)}
                    className="text-2xl hover:scale-125 active:scale-95 transition-transform"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Present Now / Screen Share */}
          <button
            onClick={toggleScreenShare}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isScreenSharing
                ? 'bg-[#8ab4f8] text-[#202124]'
                : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
            }`}
            title={isScreenSharing ? 'Stop presenting' : 'Present now'}
          >
            <Tv className="w-5 h-5" />
          </button>

          {/* Raise Hand */}
          <button
            onClick={toggleHandRaise}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
              isHandRaised
                ? 'bg-[#8ab4f8] text-[#202124]'
                : 'bg-[#3c4043] hover:bg-[#4a4e52] text-white'
            }`}
            title="Raise hand (Ctrl + h)"
          >
            <Hand className="w-5 h-5" />
          </button>

          {/* Whiteboard / Jam */}
          <button
            onClick={onOpenWhiteboard}
            className="w-11 h-11 rounded-full bg-[#3c4043] hover:bg-[#4a4e52] text-white flex items-center justify-center transition-all hidden sm:flex"
            title="Open Jam Whiteboard"
          >
            <PenTool className="w-5 h-5" />
          </button>

          {/* More options (3 vertical dots) */}
          <div className="relative">
            <button
              onClick={() => setShowMoreMenu(!showMoreMenu)}
              className="w-11 h-11 rounded-full bg-[#3c4043] hover:bg-[#4a4e52] text-white flex items-center justify-center transition-all"
              title="More options"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

            {showMoreMenu && (
              <div 
                className="absolute bottom-14 right-0 w-60 bg-[#3c4043] text-white rounded-xl shadow-2xl py-2 z-50 text-xs border border-white/10 animate-in fade-in"
                onClick={() => setShowMoreMenu(false)}
              >
                <button
                  onClick={onOpenWhiteboard}
                  className="w-full px-4 py-2.5 flex items-center gap-3 hover:bg-white/10 text-left"
                >
                  <PenTool className="w-4 h-4 text-[#8ab4f8]" />
                  <span>Whiteboard</span>
                </button>
                <button
                  onClick={() => setIsBackgroundBlur(!isBackgroundBlur)}
                  className="w-full px-4 py-2.5 flex items-center gap-3 hover:bg-white/10 text-left"
                >
                  <Sparkles className="w-4 h-4 text-[#8ab4f8]" />
                  <span>{isBackgroundBlur ? 'Turn off visual effects' : 'Apply visual effects'}</span>
                </button>
                <button
                  onClick={toggleFullscreen}
                  className="w-full px-4 py-2.5 flex items-center gap-3 hover:bg-white/10 text-left"
                >
                  {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  <span>{isFullscreen ? 'Exit full screen' : 'Full screen'}</span>
                </button>
                <button
                  onClick={onOpenSettings}
                  className="w-full px-4 py-2.5 flex items-center gap-3 hover:bg-white/10 text-left border-t border-white/10 mt-1"
                >
                  <Settings className="w-4 h-4" />
                  <span>Settings</span>
                </button>
              </div>
            )}
          </div>

          {/* Red Leave Call Button */}
          <button
            onClick={() => {
              sounds.playLeaveSound();
              onLeaveMeeting();
            }}
            className="w-14 h-11 rounded-full bg-[#ea4335] hover:bg-[#d93025] text-white flex items-center justify-center transition-all active:scale-95 shadow-md ml-1"
            title="Leave call"
          >
            <PhoneOff className="w-5 h-5" />
          </button>
        </div>

        {/* Right: Side Panel Toggle Icons */}
        <div className="hidden sm:flex items-center gap-1 text-white/80">
          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'info' ? null : 'info')}
            className={`p-2.5 rounded-full hover:bg-white/10 transition-colors ${
              activeSidePanel === 'info' ? 'text-[#8ab4f8] bg-white/10' : ''
            }`}
            title="Meeting details"
          >
            <Info className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'people' ? null : 'people')}
            className={`p-2.5 rounded-full hover:bg-white/10 transition-colors relative ${
              activeSidePanel === 'people' ? 'text-[#8ab4f8] bg-white/10' : ''
            }`}
            title="People"
          >
            <Users className="w-5 h-5" />
            <span className="absolute top-1 right-1 bg-[#8ab4f8] text-[#202124] text-[10px] font-bold px-1 rounded-full min-w-4 text-center">
              {totalParticipants}
            </span>
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'chat' ? null : 'chat')}
            className={`p-2.5 rounded-full hover:bg-white/10 transition-colors relative ${
              activeSidePanel === 'chat' ? 'text-[#8ab4f8] bg-white/10' : ''
            }`}
            title="Chat with everyone"
          >
            <MessageSquare className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'activities' ? null : 'activities')}
            className={`p-2.5 rounded-full hover:bg-white/10 transition-colors ${
              activeSidePanel === 'activities' ? 'text-[#8ab4f8] bg-white/10' : ''
            }`}
            title="Activities"
          >
            <Shapes className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveSidePanel(activeSidePanel === 'host' ? null : 'host')}
            className={`p-2.5 rounded-full hover:bg-white/10 transition-colors ${
              activeSidePanel === 'host' ? 'text-[#8ab4f8] bg-white/10' : ''
            }`}
            title="Host controls"
          >
            <ShieldCheck className="w-5 h-5" />
          </button>
        </div>
      </footer>
    </div>
  );
};
