/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  HelpCircle, 
  Settings, 
  Grid, 
  MessageSquarePlus, 
  LogOut, 
  User as UserIcon,
  CheckCircle,
  Keyboard,
  ExternalLink,
  Crown
} from 'lucide-react';
import { User } from 'firebase/auth';
import { MeetLogo } from './MeetLogo';
import { isDeveloperAccount, DeveloperCrownBadge, DEVELOPER_EMAIL, DEVELOPER_NAME } from '../services/developer';

interface NavbarProps {
  user: User | null;
  onOpenSettings: () => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onNavigateHome: () => void;
  onSetDeveloperProfile?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onOpenSettings,
  onSignIn,
  onSignOut,
  onNavigateHome,
  onSetDeveloperProfile,
}) => {
  const [timeString, setTimeString] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showHelpMenu, setShowHelpMenu] = useState(false);
  const [showAppsMenu, setShowAppsMenu] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
      const date = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
      setTimeString(`${time} • ${date}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const activeEmail = user?.email || DEVELOPER_EMAIL;
  const activeName = user?.displayName || DEVELOPER_NAME;
  const isDev = isDeveloperAccount(activeEmail, activeName);

  return (
    <header className="h-16 px-6 flex items-center justify-between border-b border-[#dadce0] bg-white select-none z-30 relative">
      {/* Left: Brand Logo + Developer Tag */}
      <div className="flex items-center gap-3">
        <MeetLogo onClick={onNavigateHome} />
        {isDev && (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 border border-amber-200/80 rounded-full">
            <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span className="text-xs font-semibold text-amber-900">Dev Mode</span>
          </div>
        )}
      </div>

      {/* Right: Date, Time & Utility Icons */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Time display */}
        <span className="hidden sm:inline-block text-sm text-[#5f6368] font-normal mr-2">
          {timeString}
        </span>

        {/* Support / Help Button */}
        <div className="relative">
          <button
            onClick={() => {
              setShowHelpMenu(!showHelpMenu);
              setShowProfileMenu(false);
              setShowAppsMenu(false);
            }}
            title="Support & Shortcuts"
            className="p-2 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          {showHelpMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border border-[#dadce0] p-4 text-sm z-50 animate-in fade-in">
              <h4 className="font-medium text-[#202124] mb-2 flex items-center gap-2">
                <Keyboard className="w-4 h-4 text-[#1a73e8]" />
                Keyboard Shortcuts
              </h4>
              <div className="space-y-2 text-xs text-[#5f6368] border-b border-[#dadce0] pb-3 mb-3">
                <div className="flex justify-between">
                  <span>Toggle microphone:</span>
                  <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border border-gray-300 font-mono">⌘/Ctrl + d</kbd>
                </div>
                <div className="flex justify-between">
                  <span>Toggle camera:</span>
                  <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border border-gray-300 font-mono">⌘/Ctrl + e</kbd>
                </div>
                <div className="flex justify-between">
                  <span>Raise hand:</span>
                  <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border border-gray-300 font-mono">⌘/Ctrl + h</kbd>
                </div>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 p-2 rounded-md">
                <Crown className="w-3.5 h-3.5 fill-amber-400 text-amber-600 shrink-0" />
                <span>Pengembang: <strong>{DEVELOPER_NAME}</strong> ({DEVELOPER_EMAIL})</span>
              </div>
            </div>
          )}
        </div>

        {/* Feedback Button */}
        <button
          onClick={() => {
            alert('SDM Meet: Thank you for your feedback! Everything is running seamlessly.');
          }}
          title="Send feedback"
          className="p-2 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors hidden sm:block"
        >
          <MessageSquarePlus className="w-5 h-5" />
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          title="Settings"
          className="p-2 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
        >
          <Settings className="w-5 h-5" />
        </button>

        {/* Google Apps 9-dots */}
        <div className="relative hidden sm:block">
          <button
            onClick={() => {
              setShowAppsMenu(!showAppsMenu);
              setShowHelpMenu(false);
              setShowProfileMenu(false);
            }}
            title="Google apps"
            className="p-2 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
          >
            <Grid className="w-5 h-5" />
          </button>

          {showAppsMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-[#dadce0] p-4 grid grid-cols-3 gap-3 z-50 text-center text-xs animate-in fade-in">
              <a href="https://meet.google.com" target="_blank" rel="noreferrer" className="flex flex-col items-center p-2 rounded-xl hover:bg-[#f1f3f4]">
                <MeetLogo showText={false} className="w-8 h-8 mb-1" />
                <span>Meet</span>
              </a>
              <a href="https://calendar.google.com" target="_blank" rel="noreferrer" className="flex flex-col items-center p-2 rounded-xl hover:bg-[#f1f3f4]">
                <div className="w-8 h-8 rounded bg-[#1a73e8] text-white font-bold flex items-center justify-center mb-1 text-sm">31</div>
                <span>Calendar</span>
              </a>
              <a href="https://mail.google.com" target="_blank" rel="noreferrer" className="flex flex-col items-center p-2 rounded-xl hover:bg-[#f1f3f4]">
                <div className="w-8 h-8 rounded bg-[#ea4335] text-white font-bold flex items-center justify-center mb-1 text-xs">M</div>
                <span>Gmail</span>
              </a>
            </div>
          )}
        </div>

        {/* Profile / Developer Section */}
        {user ? (
          <div className="relative ml-1">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowHelpMenu(false);
                setShowAppsMenu(false);
              }}
              className={`w-9 h-9 rounded-full ring-2 transition-all overflow-hidden flex items-center justify-center bg-[#1a73e8] text-white font-medium text-sm relative ${
                isDev ? 'ring-amber-400 shadow-md shadow-amber-200' : 'ring-transparent hover:ring-[#1a73e8]'
              }`}
              title={activeName}
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt={activeName} className="w-full h-full object-cover" />
              ) : (
                <span>{activeName[0].toUpperCase()}</span>
              )}
              {isDev && (
                <span className="absolute -top-1 -right-1 bg-amber-400 rounded-full p-0.5 shadow">
                  <Crown className="w-3 h-3 text-amber-900 fill-amber-900" />
                </span>
              )}
            </button>

            {/* Profile Dropdown */}
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-[#dadce0] p-4 z-50 animate-in fade-in">
                <div className="flex flex-col items-center text-center pb-3 border-b border-[#dadce0] relative">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full overflow-hidden bg-gradient-to-tr from-[#1a73e8] to-[#4285f4] text-white text-2xl font-medium flex items-center justify-center mb-2 shadow-inner ring-4 ring-amber-300">
                      {user.photoURL ? (
                        <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" />
                      ) : (
                        <span>{activeName[0].toUpperCase()}</span>
                      )}
                    </div>
                    {isDev && (
                      <div className="absolute -top-2 -right-1 bg-amber-400 text-amber-900 p-1 rounded-full shadow-md">
                        <Crown className="w-4 h-4 fill-amber-900" />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 mt-1">
                    <h3 className="font-semibold text-[#202124] text-base leading-tight">
                      {activeName}
                    </h3>
                    {isDev && <DeveloperCrownBadge size="sm" />}
                  </div>

                  <p className="text-xs text-[#5f6368] mt-0.5 font-mono">{activeEmail}</p>
                  
                  {isDev && (
                    <div className="mt-3 w-full bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 rounded-xl p-2.5 text-left">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-900">
                        <Crown className="w-4 h-4 fill-amber-500 text-amber-600" />
                        <span>Pengembang Utama SDM Meet</span>
                      </div>
                      <p className="text-[11px] text-amber-800/90 mt-1 leading-snug">
                        Terverifikasi sebagai pencipta & developer dengan hak akses sistem penuh.
                      </p>
                    </div>
                  )}

                  <div className="mt-2.5 inline-flex items-center gap-1 px-2.5 py-1 bg-[#e6f4ea] text-[#137333] rounded-full text-xs font-medium">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Google Meet Connected</span>
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      onSignOut();
                    }}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-[#dadce0] rounded-full text-sm font-medium text-[#3c4043] hover:bg-[#f8f9fa] hover:text-[#d93025] transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2 ml-1">
            {/* Quick Developer Profile Sign-in */}
            <button
              onClick={onSetDeveloperProfile}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-600 hover:to-yellow-500 text-amber-950 font-semibold text-xs rounded-full shadow-sm hover:shadow transition-all cursor-pointer"
              title="Masuk sebagai Developer (subhandeomukti@gmail.com)"
            >
              <Crown className="w-3.5 h-3.5 fill-amber-950" />
              <span>subhandeomukti 👑</span>
            </button>

            {/* Google Sign-in button */}
            <button
              onClick={onSignIn}
              className="gsi-material-button shadow-sm"
              title="Sign in with Google"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                    <path fill="none" d="M0 0h48v48H0z" />
                  </svg>
                </div>
                <span className="gsi-material-button-contents">Sign in</span>
              </div>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
