/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Mic, 
  Video, 
  Sliders, 
  Volume2, 
  Check, 
  Play
} from 'lucide-react';
import { sounds } from '../services/soundEffects';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedAudioDeviceId?: string;
  selectedVideoDeviceId?: string;
  onAudioDeviceChange?: (deviceId: string) => void;
  onVideoDeviceChange?: (deviceId: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  selectedAudioDeviceId,
  selectedVideoDeviceId,
  onAudioDeviceChange,
  onVideoDeviceChange,
}) => {
  const [activeTab, setActiveTab] = useState<'audio' | 'video' | 'general'>('audio');
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [audioMeter, setAudioMeter] = useState(20);
  const [sendResolution, setSendResolution] = useState('High definition (720p)');
  const [receiveResolution, setReceiveResolution] = useState('High definition (720p)');
  const [noiseCancellation, setNoiseCancellation] = useState(true);
  const [leaveEmptyCalls, setLeaveEmptyCalls] = useState(true);

  useEffect(() => {
    if (!isOpen) return;

    // Enumerate devices
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      navigator.mediaDevices.enumerateDevices().then(devices => {
        const audioInputs = devices.filter(d => d.kind === 'audioinput');
        const videoInputs = devices.filter(d => d.kind === 'videoinput');
        setAudioDevices(audioInputs);
        setVideoDevices(videoInputs);
      }).catch(err => {
        console.warn('Could not enumerate devices:', err);
      });
    }

    // Gentle meter fluctuation for preview visual
    const interval = setInterval(() => {
      setAudioMeter(Math.floor(15 + Math.random() * 45));
    }, 200);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-2xl overflow-hidden flex flex-col h-[520px]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#dadce0]">
          <h2 className="text-xl font-normal text-[#202124]">Settings</h2>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-full hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body with sidebar tabs */}
        <div className="flex flex-1 overflow-hidden">
          {/* Tabs Sidebar */}
          <div className="w-48 border-r border-[#dadce0] py-2 bg-[#f8f9fa] shrink-0">
            <button
              onClick={() => setActiveTab('audio')}
              className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium transition-colors text-left ${
                activeTab === 'audio' 
                  ? 'bg-[#e8f0fe] text-[#1a73e8] border-r-4 border-[#1a73e8]' 
                  : 'text-[#3c4043] hover:bg-black/5'
              }`}
            >
              <Mic className="w-5 h-5 shrink-0" />
              <span>Audio</span>
            </button>
            <button
              onClick={() => setActiveTab('video')}
              className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium transition-colors text-left ${
                activeTab === 'video' 
                  ? 'bg-[#e8f0fe] text-[#1a73e8] border-r-4 border-[#1a73e8]' 
                  : 'text-[#3c4043] hover:bg-black/5'
              }`}
            >
              <Video className="w-5 h-5 shrink-0" />
              <span>Video</span>
            </button>
            <button
              onClick={() => setActiveTab('general')}
              className={`w-full flex items-center gap-3 px-6 py-3 text-sm font-medium transition-colors text-left ${
                activeTab === 'general' 
                  ? 'bg-[#e8f0fe] text-[#1a73e8] border-r-4 border-[#1a73e8]' 
                  : 'text-[#3c4043] hover:bg-black/5'
              }`}
            >
              <Sliders className="w-5 h-5 shrink-0" />
              <span>General</span>
            </button>
          </div>

          {/* Tab Content Panel */}
          <div className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'audio' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#5f6368] mb-1.5">
                    Microphone
                  </label>
                  <select
                    value={selectedAudioDeviceId || ''}
                    onChange={(e) => onAudioDeviceChange?.(e.target.value)}
                    className="w-full border border-[#dadce0] rounded-md px-3.5 py-2.5 text-sm text-[#202124] focus:border-[#1a73e8] focus:outline-none focus:ring-1 focus:ring-[#1a73e8] bg-white"
                  >
                    {audioDevices.length > 0 ? (
                      audioDevices.map((d, i) => (
                        <option key={d.deviceId || i} value={d.deviceId}>
                          {d.label || `Microphone ${i + 1}`}
                        </option>
                      ))
                    ) : (
                      <option value="">Default - System Microphone</option>
                    )}
                  </select>

                  {/* Mic level meter */}
                  <div className="mt-3 flex items-center gap-3">
                    <Mic className="w-4 h-4 text-[#5f6368]" />
                    <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                      <div 
                        className="bg-[#1a73e8] h-full transition-all duration-150"
                        style={{ width: `${audioMeter}%` }}
                      />
                    </div>
                    <span className="text-xs text-[#5f6368] w-8">{audioMeter}%</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#5f6368] mb-1.5">
                    Speakers
                  </label>
                  <div className="flex items-center gap-3">
                    <select
                      className="flex-1 border border-[#dadce0] rounded-md px-3.5 py-2.5 text-sm text-[#202124] focus:border-[#1a73e8] focus:outline-none focus:ring-1 focus:ring-[#1a73e8] bg-white"
                    >
                      <option value="default">Default - System Speakers / Headphones</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => sounds.playJoinSound()}
                      className="flex items-center gap-1.5 px-3 py-2 border border-[#dadce0] rounded-md text-sm font-medium text-[#1a73e8] hover:bg-[#f1f3f4] transition-colors"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Test
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#dadce0]">
                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={noiseCancellation}
                      onChange={(e) => setNoiseCancellation(e.target.checked)}
                      className="mt-1 h-4 w-4 rounded text-[#1a73e8] focus:ring-[#1a73e8]"
                    />
                    <div>
                      <span className="text-sm font-medium text-[#202124] block">Noise cancellation</span>
                      <span className="text-xs text-[#5f6368] block mt-0.5">
                        Filters out background sound from your audio that isn't speech
                      </span>
                    </div>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'video' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#5f6368] mb-1.5">
                    Camera
                  </label>
                  <select
                    value={selectedVideoDeviceId || ''}
                    onChange={(e) => onVideoDeviceChange?.(e.target.value)}
                    className="w-full border border-[#dadce0] rounded-md px-3.5 py-2.5 text-sm text-[#202124] focus:border-[#1a73e8] focus:outline-none focus:ring-1 focus:ring-[#1a73e8] bg-white"
                  >
                    {videoDevices.length > 0 ? (
                      videoDevices.map((d, i) => (
                        <option key={d.deviceId || i} value={d.deviceId}>
                          {d.label || `Camera ${i + 1}`}
                        </option>
                      ))
                    ) : (
                      <option value="">Default - FaceTime / Integrated Webcam</option>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#5f6368] mb-1.5">
                    Send resolution (maximum)
                  </label>
                  <select
                    value={sendResolution}
                    onChange={(e) => setSendResolution(e.target.value)}
                    className="w-full border border-[#dadce0] rounded-md px-3.5 py-2.5 text-sm text-[#202124] focus:border-[#1a73e8] focus:outline-none focus:ring-1 focus:ring-[#1a73e8] bg-white"
                  >
                    <option value="High definition (720p)">High definition (720p)</option>
                    <option value="Standard definition (360p)">Standard definition (360p)</option>
                    <option value="Auto">Auto</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[#5f6368] mb-1.5">
                    Receive resolution (maximum)
                  </label>
                  <select
                    value={receiveResolution}
                    onChange={(e) => setReceiveResolution(e.target.value)}
                    className="w-full border border-[#dadce0] rounded-md px-3.5 py-2.5 text-sm text-[#202124] focus:border-[#1a73e8] focus:outline-none focus:ring-1 focus:ring-[#1a73e8] bg-white"
                  >
                    <option value="High definition (720p)">High definition (720p)</option>
                    <option value="Standard definition (360p)">Standard definition (360p)</option>
                    <option value="Audio only">Audio only</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === 'general' && (
              <div className="space-y-6">
                <div>
                  <label className="flex items-start gap-3 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={leaveEmptyCalls}
                      onChange={(e) => setLeaveEmptyCalls(e.target.checked)}
                      className="mt-1 h-4 w-4 rounded text-[#1a73e8] focus:ring-[#1a73e8]"
                    />
                    <div>
                      <span className="text-sm font-medium text-[#202124] block">
                        Leave empty calls
                      </span>
                      <span className="text-xs text-[#5f6368] block mt-0.5">
                        Automatically disconnects you after 5 minutes if you are the only participant in the meeting.
                      </span>
                    </div>
                  </label>
                </div>

                <div className="pt-4 border-t border-[#dadce0]">
                  <h4 className="text-sm font-medium text-[#202124] mb-1">About SDM Meet</h4>
                  <p className="text-xs text-[#5f6368] leading-relaxed">
                    SDM Meet is built with Google Meet Workspace technology, offering secure, high-definition enterprise video conferencing and collaborative tools for everyone.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#dadce0] bg-[#f8f9fa] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#1a73e8] hover:bg-[#1557b0] text-white text-sm font-medium rounded-md shadow-sm transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
