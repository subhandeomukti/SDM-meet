/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { X, Eraser, Pen, RotateCcw, Download, Square, Circle } from 'lucide-react';

interface WhiteboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  meetingCode: string;
}

export const WhiteboardModal: React.FC<WhiteboardModalProps> = ({
  isOpen,
  onClose,
  meetingCode,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [tool, setTool] = useState<'pen' | 'eraser' | 'rect' | 'circle'>('pen');
  const [color, setColor] = useState('#1a73e8');
  const [brushSize, setBrushSize] = useState(4);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<{ x: number; y: number } | null>(null);
  const [snapshot, setSnapshot] = useState<ImageData | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set high-res canvas backing
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, [isOpen]);

  if (!isOpen) return null;

  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setIsDrawing(true);
    setStartPos({ x, y });
    setSnapshot(ctx.getImageData(0, 0, canvas.width, canvas.height));

    if (tool === 'pen' || tool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
      ctx.lineWidth = tool === 'eraser' ? brushSize * 4 : brushSize;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (tool === 'pen' || tool === 'eraser') {
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (snapshot && startPos) {
      ctx.putImageData(snapshot, 0, 0);
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = brushSize;
      if (tool === 'rect') {
        ctx.strokeRect(startPos.x, startPos.y, x - startPos.x, y - startPos.y);
      } else if (tool === 'circle') {
        const radius = Math.sqrt(Math.pow(x - startPos.x, 2) + Math.pow(y - startPos.y, 2));
        ctx.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
        ctx.stroke();
      }
    }
  };

  const stopDraw = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `sdm-meet-whiteboard-${meetingCode}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-[2px] p-4">
      <div className="w-full max-w-4xl h-[600px] bg-white rounded-lg shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-[#dadce0] bg-[#f8f9fa]">
          <div className="flex items-center gap-2">
            <span className="font-medium text-[#202124] text-base">SDM Jam - Collaborative Whiteboard</span>
            <span className="text-xs bg-[#e8f0fe] text-[#1a73e8] px-2 py-0.5 rounded-full font-mono">
              {meetingCode}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={downloadCanvas}
              title="Download snapshot"
              className="p-1.5 rounded-md hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
            >
              <Download className="w-5 h-5" />
            </button>
            <button
              onClick={clearCanvas}
              title="Clear board"
              className="p-1.5 rounded-md hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md hover:bg-black/5 text-[#5f6368] hover:text-[#202124] transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-4 px-6 py-2 border-b border-[#e8eaed] bg-white">
          <div className="flex items-center gap-1 bg-[#f1f3f4] p-1 rounded-lg">
            <button
              onClick={() => setTool('pen')}
              className={`p-1.5 rounded ${tool === 'pen' ? 'bg-white shadow text-[#1a73e8]' : 'text-[#5f6368]'}`}
              title="Pen"
            >
              <Pen className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTool('eraser')}
              className={`p-1.5 rounded ${tool === 'eraser' ? 'bg-white shadow text-[#1a73e8]' : 'text-[#5f6368]'}`}
              title="Eraser"
            >
              <Eraser className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTool('rect')}
              className={`p-1.5 rounded ${tool === 'rect' ? 'bg-white shadow text-[#1a73e8]' : 'text-[#5f6368]'}`}
              title="Rectangle"
            >
              <Square className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTool('circle')}
              className={`p-1.5 rounded ${tool === 'circle' ? 'bg-white shadow text-[#1a73e8]' : 'text-[#5f6368]'}`}
              title="Circle"
            >
              <Circle className="w-4 h-4" />
            </button>
          </div>

          {/* Color palette */}
          <div className="flex items-center gap-1.5">
            {['#1a73e8', '#ea4335', '#fbbc04', '#34a853', '#202124', '#9333ea'].map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-6 h-6 rounded-full transition-transform ${
                  color === c ? 'scale-125 ring-2 ring-offset-2 ring-[#1a73e8]' : 'hover:scale-110'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          {/* Stroke size */}
          <div className="flex items-center gap-2 ml-auto text-xs text-[#5f6368]">
            <span>Size</span>
            <input
              type="range"
              min={2}
              max={16}
              value={brushSize}
              onChange={(e) => setBrushSize(Number(e.target.value))}
              className="w-24 accent-[#1a73e8]"
            />
          </div>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 bg-[#f8f9fa] p-4 flex items-center justify-center overflow-hidden">
          <canvas
            ref={canvasRef}
            onMouseDown={startDraw}
            onMouseMove={draw}
            onMouseUp={stopDraw}
            onMouseLeave={stopDraw}
            className="w-full h-full bg-white shadow-md rounded border border-[#dadce0] cursor-crosshair"
          />
        </div>
      </div>
    </div>
  );
};
