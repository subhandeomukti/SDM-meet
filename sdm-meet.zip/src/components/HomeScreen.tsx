/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Video, 
  Keyboard, 
  Link2, 
  Plus, 
  Calendar, 
  ChevronLeft, 
  ChevronRight,
  ShieldCheck,
  Share2,
  CalendarCheck,
  Sparkles,
  ArrowRight,
  Crown
} from 'lucide-react';
import { DEVELOPER_EMAIL, DEVELOPER_NAME, DeveloperCrownBadge } from '../services/developer';

interface HomeScreenProps {
  onStartInstantMeeting: () => void;
  onCreateMeetingForLater: () => void;
  onJoinMeeting: (code: string) => void;
  isCreatingMeeting?: boolean;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onStartInstantMeeting,
  onCreateMeetingForLater,
  onJoinMeeting,
  isCreatingMeeting = false,
}) => {
  const [meetingInput, setMeetingInput] = useState('');
  const [showNewMeetingDropdown, setShowNewMeetingDropdown] = useState(false);
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      title: 'Get a link you can share',
      description: 'Click New meeting to get a link you can send to people you want to meet with',
      icon: (
        <div className="w-56 h-56 rounded-full bg-[#e8f0fe] flex items-center justify-center relative shadow-inner">
          <div className="w-36 h-36 rounded-full bg-white shadow-lg flex items-center justify-center">
            <Share2 className="w-16 h-16 text-[#1a73e8]" />
          </div>
          <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-[#137333] text-white flex items-center justify-center shadow-md">
            <Link2 className="w-5 h-5" />
          </div>
        </div>
      ),
    },
    {
      title: 'Plan ahead',
      description: 'Click New meeting to schedule meetings in Google Calendar and send invites to attendees',
      icon: (
        <div className="w-56 h-56 rounded-full bg-[#fce8e6] flex items-center justify-center relative shadow-inner">
          <div className="w-36 h-36 rounded-full bg-white shadow-lg flex items-center justify-center">
            <CalendarCheck className="w-16 h-16 text-[#d93025]" />
          </div>
          <div className="absolute bottom-6 right-8 w-10 h-10 rounded-full bg-[#1a73e8] text-white flex items-center justify-center shadow-md">
            <Sparkles className="w-5 h-5" />
          </div>
        </div>
      ),
    },
    {
      title: 'Your meeting is safe',
      description: 'No one can join a meeting unless invited or admitted by the host',
      icon: (
        <div className="w-56 h-56 rounded-full bg-[#e6f4ea] flex items-center justify-center relative shadow-inner">
          <div className="w-36 h-36 rounded-full bg-white shadow-lg flex items-center justify-center">
            <ShieldCheck className="w-16 h-16 text-[#188038]" />
          </div>
          <div className="absolute top-8 left-6 w-9 h-9 rounded-full bg-[#f9ab00] text-white flex items-center justify-center shadow-md">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>
      ),
    },
  ];

  // Auto rotate carousel every 6s
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!meetingInput.trim()) return;
    
    // Clean input if user pasted full URL (e.g., https://meet.google.com/abc-defg-hij)
    let code = meetingInput.trim();
    if (code.includes('meet.google.com/')) {
      code = code.split('meet.google.com/')[1].split(/[?#]/)[0];
    }
    onJoinMeeting(code);
  };

  return (
    <div className="flex-1 flex flex-col justify-center px-6 lg:px-16 py-12 max-w-7xl mx-auto w-full min-h-[calc(100vh-64px)]">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column: Hero Call to Action */}
        <div className="lg:col-span-7 flex flex-col justify-center max-w-2xl">
          <h1 className="text-4xl sm:text-[44px] leading-tight font-normal text-[#202124] tracking-tight">
            Video calls and meetings for everyone
          </h1>
          <p className="mt-4 text-lg text-[#5f6368] font-normal leading-relaxed">
            Connect, collaborate, and celebrate from anywhere with <span className="text-[#1a73e8] font-medium">SDM Meet</span>. Safe, encrypted, and built with Google Meet.
          </p>

          {/* Action Row */}
          <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 relative">
            {/* New Meeting Dropdown Button */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNewMeetingDropdown(!showNewMeetingDropdown)}
                disabled={isCreatingMeeting}
                className="w-full sm:w-auto h-12 px-5 bg-[#1a73e8] hover:bg-[#1557b0] text-white rounded-md font-medium text-sm flex items-center justify-center gap-2.5 shadow hover:shadow-md transition-all active:scale-[0.98] disabled:opacity-70 cursor-pointer"
              >
                <Video className="w-5 h-5 shrink-0" />
                <span>{isCreatingMeeting ? 'Creating space...' : 'New meeting'}</span>
              </button>

              {/* Dropdown Menu */}
              {showNewMeetingDropdown && (
                <div 
                  className="absolute left-0 mt-2 w-72 bg-white rounded-lg shadow-2xl border border-[#dadce0] py-2 z-40 animate-in fade-in"
                  onClick={() => setShowNewMeetingDropdown(false)}
                >
                  <button
                    onClick={onCreateMeetingForLater}
                    className="w-full px-4 py-3 flex items-center gap-3.5 text-left text-sm text-[#202124] hover:bg-[#f1f3f4] transition-colors"
                  >
                    <Link2 className="w-5 h-5 text-[#5f6368]" />
                    <span>Create a meeting for later</span>
                  </button>

                  <button
                    onClick={onStartInstantMeeting}
                    className="w-full px-4 py-3 flex items-center gap-3.5 text-left text-sm text-[#202124] hover:bg-[#f1f3f4] transition-colors"
                  >
                    <Plus className="w-5 h-5 text-[#5f6368]" />
                    <span>Start an instant meeting</span>
                  </button>

                  <a
                    href="https://calendar.google.com/calendar/u/0/r/eventedit"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full px-4 py-3 flex items-center gap-3.5 text-left text-sm text-[#202124] hover:bg-[#f1f3f4] transition-colors"
                  >
                    <Calendar className="w-5 h-5 text-[#5f6368]" />
                    <span>Schedule in Google Calendar</span>
                  </a>
                </div>
              )}
            </div>

            {/* Meeting code input form */}
            <form onSubmit={handleJoin} className="flex-1 flex items-center gap-2">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#5f6368]">
                  <Keyboard className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  value={meetingInput}
                  onChange={(e) => setMeetingInput(e.target.value)}
                  placeholder="Enter a code or link"
                  className="w-full h-12 pl-11 pr-4 border border-[#747775] hover:border-[#202124] focus:border-[#1a73e8] focus:ring-1 focus:ring-[#1a73e8] rounded-md text-sm text-[#202124] bg-white placeholder:text-[#5f6368] outline-none transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={!meetingInput.trim()}
                className={`h-12 px-6 rounded-md text-sm font-medium transition-all ${
                  meetingInput.trim()
                    ? 'text-[#1a73e8] hover:bg-[#e8f0fe] cursor-pointer'
                    : 'text-[#80868b] cursor-not-allowed'
                }`}
              >
                Join
              </button>
            </form>
          </div>

          {/* Divider & Info with Developer Badge */}
          <div className="mt-10 pt-6 border-t border-[#dadce0] flex flex-wrap items-center justify-between gap-3 text-sm text-[#5f6368]">
            <a 
              href="#learn-more" 
              onClick={(e) => {
                e.preventDefault();
                alert(`SDM Meet dikembangkan oleh ${DEVELOPER_NAME} (${DEVELOPER_EMAIL}) dengan teknologi Google Meet.`);
              }}
              className="text-[#1a73e8] hover:underline flex items-center gap-1 font-medium"
            >
              Learn more about SDM Meet
              <ArrowRight className="w-4 h-4" />
            </a>

            {/* Developer Crown Tag */}
            <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200/90 rounded-full shadow-xs">
              <Crown className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
              <span className="text-xs text-amber-900 font-medium">
                Developer: <strong className="font-semibold">{DEVELOPER_NAME}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Carousel Illustration */}
        <div className="lg:col-span-5 flex flex-col items-center text-center">
          <div className="w-full max-w-sm flex flex-col items-center">
            {/* Slide Graphic */}
            <div className="h-64 flex items-center justify-center transition-all duration-300">
              {slides[activeSlide].icon}
            </div>

            {/* Slide Title */}
            <h3 className="mt-6 text-xl font-normal text-[#202124]">
              {slides[activeSlide].title}
            </h3>

            {/* Slide Description */}
            <p className="mt-2 text-sm text-[#5f6368] leading-relaxed px-4 min-h-[40px]">
              {slides[activeSlide].description}
            </p>

            {/* Navigation Dots & Chevrons */}
            <div className="mt-6 flex items-center gap-4">
              <button
                onClick={() => setActiveSlide((prev) => (prev - 1 + slides.length) % slides.length)}
                className="p-1 rounded-full text-[#5f6368] hover:bg-black/5 transition-colors"
                title="Previous slide"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2">
                {slides.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveSlide(idx)}
                    className={`h-2 rounded-full transition-all ${
                      activeSlide === idx ? 'w-4 bg-[#1a73e8]' : 'w-2 bg-[#dadce0]'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={() => setActiveSlide((prev) => (prev + 1) % slides.length)}
                className="p-1 rounded-full text-[#5f6368] hover:bg-black/5 transition-colors"
                title="Next slide"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
