/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Copy, Check, ExternalLink } from 'lucide-react';

interface CreateLaterModalProps {
  isOpen: boolean;
  onClose: () => void;
  meetingLink: string;
  meetingCode: string;
  onJoinNow: (code: string) => void;
}

export const CreateLaterModal: React.FC<CreateLaterModalProps> = ({
  isOpen,
  onClose,
  meetingLink,
  meetingCode,
  onJoinNow,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(meetingLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-[1px] p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-white rounded-lg shadow-2xl p-6 relative">
        <div className="flex items-center justify-between pb-3">
          <h3 className="text-lg font-medium text-[#202124]">
            Here's the link to your meeting
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-[#5f6368] hover:bg-black/5 hover:text-[#202124] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-[#5f6368] mt-2 leading-relaxed">
          Copy this link and send it to people you want to meet with. Be sure to save it so you can use it later, too.
        </p>

        {/* Link Box */}
        <div className="mt-4 flex items-center justify-between bg-[#f1f3f4] rounded-md px-3.5 py-2.5">
          <span className="text-sm font-medium text-[#202124] truncate mr-2 select-all font-mono">
            {meetingLink}
          </span>
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-full hover:bg-black/10 text-[#5f6368] hover:text-[#202124] transition-colors relative"
            title="Copy link"
          >
            {copied ? (
              <Check className="w-5 h-5 text-[#137333]" />
            ) : (
              <Copy className="w-5 h-5" />
            )}
          </button>
        </div>

        {copied && (
          <div className="mt-2 text-xs font-medium text-[#137333] flex items-center gap-1.5 animate-in fade-in">
            <Check className="w-3.5 h-3.5" />
            <span>Meeting link copied to clipboard</span>
          </div>
        )}

        <div className="mt-6 flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-[#5f6368] hover:bg-black/5 rounded-md transition-colors"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onJoinNow(meetingCode);
            }}
            className="px-4 py-2 text-sm font-medium text-white bg-[#1a73e8] hover:bg-[#1557b0] rounded-md transition-colors shadow-sm flex items-center gap-2"
          >
            <span>Join now</span>
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
