/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MeetingSpace {
  name: string; // e.g. "spaces/ABC-DEFG-HIJ"
  meetingUri: string; // e.g. "https://meet.google.com/abc-defg-hij"
  meetingCode: string; // e.g. "abc-defg-hij"
  config?: {
    accessType?: string;
    entryPointAccess?: string;
  };
}

export function generateRandomMeetCode(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz';
  const segment = (len: number) =>
    Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${segment(3)}-${segment(4)}-${segment(3)}`;
}

export async function createGoogleMeetSpace(accessToken: string | null): Promise<MeetingSpace> {
  if (accessToken) {
    try {
      const response = await fetch('https://meet.googleapis.com/v2/spaces', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const data = await response.json();
        return {
          name: data.name || `spaces/${generateRandomMeetCode()}`,
          meetingUri: data.meetingUri || `https://meet.google.com/${generateRandomMeetCode()}`,
          meetingCode: data.meetingCode || data.meetingUri?.split('/').pop() || generateRandomMeetCode(),
          config: data.config,
        };
      } else {
        console.warn('Google Meet API returned non-OK status:', response.status);
      }
    } catch (err) {
      console.error('Error creating Google Meet space:', err);
    }
  }

  // Fallback to SDM Meet generated space code
  const code = generateRandomMeetCode();
  return {
    name: `spaces/${code}`,
    meetingUri: `https://meet.google.com/${code}`,
    meetingCode: code,
  };
}
