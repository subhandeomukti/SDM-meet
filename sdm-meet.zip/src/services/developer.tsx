/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Crown } from 'lucide-react';

export const DEVELOPER_EMAIL = 'subhandeomukti@gmail.com';
export const DEVELOPER_NAME = 'subhandeomukti';

export const isDeveloperAccount = (email?: string | null, name?: string | null): boolean => {
  if (!email && !name) return true; // Default to developer view for the owner
  const cleanEmail = (email || '').toLowerCase().trim();
  const cleanName = (name || '').toLowerCase().trim();
  return (
    cleanEmail === DEVELOPER_EMAIL.toLowerCase() ||
    cleanEmail.includes('subhandeomukti') ||
    cleanEmail.includes('subhnadeomukti') ||
    cleanEmail.includes('subhandeo') ||
    cleanName.includes('subhandeomukti') ||
    cleanName.includes('subhnadeomukti')
  );
};

export const DeveloperCrownBadge: React.FC<{ 
  showLabel?: boolean; 
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}> = ({ showLabel = true, size = 'sm', className = '' }) => {
  const iconSize = size === 'lg' ? 'w-5 h-5' : size === 'md' ? 'w-4 h-4' : 'w-3.5 h-3.5';
  
  return (
    <span 
      className={`inline-flex items-center gap-1 bg-gradient-to-r from-amber-500 to-yellow-400 text-white font-medium rounded-full shadow-sm shadow-amber-200/50 ${
        size === 'lg' ? 'px-3 py-1 text-xs' : size === 'md' ? 'px-2 py-0.5 text-[11px]' : 'px-1.5 py-0.5 text-[10px]'
      } ${className}`}
      title="Pengembang Resmi SDM Meet (subhandeomukti@gmail.com)"
    >
      <Crown className={`${iconSize} fill-yellow-200 text-amber-900 animate-pulse`} />
      {showLabel && <span className="font-semibold tracking-wide drop-shadow-xs">Developer</span>}
    </span>
  );
};
