/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { Navbar } from './components/Navbar';
import { HomeScreen } from './components/HomeScreen';
import { LobbyScreen } from './components/LobbyScreen';
import { MeetingRoom } from './components/MeetingRoom';
import { SettingsModal } from './components/SettingsModal';
import { CreateLaterModal } from './components/CreateLaterModal';
import { WhiteboardModal } from './components/WhiteboardModal';
import { initAuth, googleSignIn, logout, getAccessToken } from './services/auth';
import { createGoogleMeetSpace, generateRandomMeetCode } from './services/meetApi';

export default function App() {
  const [view, setView] = useState<'home' | 'lobby' | 'meeting'>('home');
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  
  // Meeting details
  const [currentMeetingCode, setCurrentMeetingCode] = useState<string>('');
  const [isCreatingMeeting, setIsCreatingMeeting] = useState(false);

  // Pre-join lobby settings
  const [lobbyOptions, setLobbyOptions] = useState({
    isMicMuted: false,
    isVideoOff: false,
    isPresenting: false,
  });

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isWhiteboardOpen, setIsWhiteboardOpen] = useState(false);
  const [isCreateLaterOpen, setIsCreateLaterOpen] = useState(false);
  const [createLaterLink, setCreateLaterLink] = useState('');

  // Audio/Video device selection
  const [selectedAudioDeviceId, setSelectedAudioDeviceId] = useState<string | undefined>();
  const [selectedVideoDeviceId, setSelectedVideoDeviceId] = useState<string | undefined>();

  // Initialize Firebase Auth
  useEffect(() => {
    const unsubscribe = initAuth(
      (authUser, authToken) => {
        setUser(authUser);
        setToken(authToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
      }
    } catch (err) {
      console.warn('Google sign-in completed or cancelled:', err);
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
    setUser(null);
    setToken(null);
  };

  // Start Instant Meeting
  const handleStartInstantMeeting = async () => {
    setIsCreatingMeeting(true);
    try {
      const activeToken = token || (await getAccessToken());
      const space = await createGoogleMeetSpace(activeToken);
      setCurrentMeetingCode(space.meetingCode);
      setView('lobby');
    } catch (err) {
      console.error('Failed to create instant meeting space:', err);
      setCurrentMeetingCode(generateRandomMeetCode());
      setView('lobby');
    } finally {
      setIsCreatingMeeting(false);
    }
  };

  // Create Meeting for Later
  const handleCreateMeetingForLater = async () => {
    setIsCreatingMeeting(true);
    try {
      const activeToken = token || (await getAccessToken());
      const space = await createGoogleMeetSpace(activeToken);
      setCurrentMeetingCode(space.meetingCode);
      setCreateLaterLink(space.meetingUri);
      setIsCreateLaterOpen(true);
    } catch (err) {
      const fallbackCode = generateRandomMeetCode();
      setCurrentMeetingCode(fallbackCode);
      setCreateLaterLink(`https://meet.google.com/${fallbackCode}`);
      setIsCreateLaterOpen(true);
    } finally {
      setIsCreatingMeeting(false);
    }
  };

  // Join Existing Meeting via Code
  const handleJoinMeeting = (code: string) => {
    const cleanCode = code.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
    setCurrentMeetingCode(cleanCode || generateRandomMeetCode());
    setView('lobby');
  };

  // Proceed from Lobby to In-Call Meeting
  const handleJoinFromLobby = (options: { isMicMuted: boolean; isVideoOff: boolean; isPresenting: boolean }) => {
    setLobbyOptions(options);
    setView('meeting');
  };

  // Leave Meeting and return to Home
  const handleLeaveMeeting = () => {
    setView('home');
  };

  const handleSetDeveloperProfile = () => {
    setUser({
      uid: 'dev-subhandeomukti-uid',
      displayName: 'subhandeomukti',
      email: 'subhandeomukti@gmail.com',
      photoURL: null,
      emailVerified: true,
      isAnonymous: false,
    } as unknown as User);
  };

  return (
    <div className="min-h-screen bg-white text-[#202124] flex flex-col font-sans select-none antialiased">
      {/* Top Navbar only shown on Home & Lobby screens; In-call has its own Meet bar */}
      {view !== 'meeting' && (
        <Navbar
          user={user}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onSignIn={handleSignIn}
          onSignOut={handleSignOut}
          onNavigateHome={() => setView('home')}
          onSetDeveloperProfile={handleSetDeveloperProfile}
        />
      )}

      {/* Main Views */}
      <main className="flex-1 flex flex-col">
        {view === 'home' && (
          <HomeScreen
            onStartInstantMeeting={handleStartInstantMeeting}
            onCreateMeetingForLater={handleCreateMeetingForLater}
            onJoinMeeting={handleJoinMeeting}
            isCreatingMeeting={isCreatingMeeting}
          />
        )}

        {view === 'lobby' && (
          <LobbyScreen
            meetingCode={currentMeetingCode}
            user={user}
            onJoinMeeting={handleJoinFromLobby}
            onBackToHome={() => setView('home')}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {view === 'meeting' && (
          <MeetingRoom
            meetingCode={currentMeetingCode}
            user={user}
            initialMicMuted={lobbyOptions.isMicMuted}
            initialVideoOff={lobbyOptions.isVideoOff}
            initialPresenting={lobbyOptions.isPresenting}
            onLeaveMeeting={handleLeaveMeeting}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenWhiteboard={() => setIsWhiteboardOpen(true)}
          />
        )}
      </main>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        selectedAudioDeviceId={selectedAudioDeviceId}
        selectedVideoDeviceId={selectedVideoDeviceId}
        onAudioDeviceChange={setSelectedAudioDeviceId}
        onVideoDeviceChange={setSelectedVideoDeviceId}
      />

      <CreateLaterModal
        isOpen={isCreateLaterOpen}
        onClose={() => setIsCreateLaterOpen(false)}
        meetingLink={createLaterLink}
        meetingCode={currentMeetingCode}
        onJoinNow={(code) => {
          setCurrentMeetingCode(code);
          setView('lobby');
        }}
      />

      <WhiteboardModal
        isOpen={isWhiteboardOpen}
        onClose={() => setIsWhiteboardOpen(false)}
        meetingCode={currentMeetingCode}
      />
    </div>
  );
}
